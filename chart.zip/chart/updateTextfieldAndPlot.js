function updateTextfield(yearVar){
    dateString = myData[0].Peak_Date + "";
    numToDate(dateString);
    plotYear = parseInt(yearVar) + parseInt(year)
    document.getElementById("yearText").value = plotYear;

    google.charts.setOnLoadCallback(drawCalendarLevelChart);
    google.charts.setOnLoadCallback(drawCalendarFlowChart);
    google.charts.setOnLoadCallback(drawBubbleChart); 
}
