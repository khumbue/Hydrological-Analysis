function updateCalendarChartByTextfield(yearVar){
    plotYear = parseInt(yearVar);

    google.charts.setOnLoadCallback(drawCalendarLevelChart);   
    google.charts.setOnLoadCallback(drawCalendarFlowChart);  
    google.charts.setOnLoadCallback(drawBubbleChart);   
}
