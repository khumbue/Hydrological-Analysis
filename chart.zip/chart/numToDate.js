// dateString format (e.g yearmonthday 19870822)
function numToDate(dateString){
    year = dateString.slice(0,4);
    month = dateString.slice(4,6);
    day = dateString.slice(6,8);            
}