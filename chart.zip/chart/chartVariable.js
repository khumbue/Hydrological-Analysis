var myData = JSON.parse(c5h012);
var year = 0;
var plotYear = 1999;
var month = 0;
var day = 0;