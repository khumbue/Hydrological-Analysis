function updateChartsByTextfield(yearVar){
    plotYear = parseInt(yearVar);
    updateCharts();
}
