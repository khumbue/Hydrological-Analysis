var myData = JSON.parse(c1h001);
var year = 0;
var plotYear = 1977;
var plotMonth = 10;
var month = 0;
var day = 0;
var date = new Date();