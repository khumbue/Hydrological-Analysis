var Model = require('./models/models.js');
var express = require('express');
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
var morgan = require('morgan');

var app = express();

app.use(bodyParser.json());

app.use(bodyParser.urlencoded({ extended: true }));


var db = "mongodb://127.0.0.1:27017/vaal_questa";

mongoose.connect(db, function(err, response){
	if(err){
		console.log('Failed to connected to ' + db);
	}
	else {
		console.log('Connected to ' + db);
	}
});


var router = express.Router();


// GET

router.get('/api/stations', function(request, response){

	Model.find({}, function(err, stations){
		if(err){
			response.status(404).send(err);
		}
		else {
			response.status(200).send(stations)
		}
	})

});

// DELETE

router.delete('/api/stations/:id', function(request, response){
	var id = request.params.id;
	Model.remove({_id: id}, function(err, res){
		if(err){
			response.status(500).send(err);
		}
		else {
			response.status(200).send({message: 'success on deleting station'});
		}
	})
})

// PUT

router.put('/api/stations', function(request, response){

	Model.findById(request.body._id, function(err, station){
		if(err){
			response.status(404).send(err);
		}
		else {
			station.update(request.body, function(err, success){
				if(err){
					response.send(err)
				}
				else {
					response.status(200).send({message: 'success'})
				}
			});
		}
	})

});



// POST

router.post('/api/stations', function(request, response){
	console.log(request.body);
	var model = new Model();
	model.Station_No = request.body.Station_No;
	model.Catchment_Area = request.body.Catchment_Area;
	model.save(function(err, station){
		if(err){
			response.status(500).send(err)
		}
		else {
			response.status(201).send(station)
		}
	});
});


app.use('/', router);


app.use(morgan('dev'));

app.use(express.static(__dirname + '/public'));

var port = process.env.PORT || 3000

app.listen(port , function(){
	console.log('Listening on port ' + port);
})


